/**
 * Configuração de autenticação e API
 */

// URL base da API
export const API_BASE_URL = '/api'; 